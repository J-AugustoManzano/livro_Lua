-- inicio do programa cap0712.lua

   A = 1
   B = 2.5
   C = "Alo, Mundo!"
   D = 'A'
   E = true
   F = string.format
   
   print("A = " .. type(A))
   print("B = " .. type(B))
   print("C = " .. type(C))
   print("D = " .. type(D))
   print("E = " .. type(E))
   print("F = " .. type(F))

   print()
   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0712.lua
