-- inicio do programa cap0719.lua

   print(tonumber("1010",2)) 
   print(tonumber("A",16))  
   print(tonumber("a",16))  
   print(tonumber("12",8))  

   print(tonumber("10111111001100011001011110001101111110110101101",2))

   print()
   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0719.lua
