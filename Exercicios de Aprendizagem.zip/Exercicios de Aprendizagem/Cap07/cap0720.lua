-- inicio do programa cap0720.lua

   print(string.format("%x", 10)) 
   print(string.format("%X", 10)) 
   print(string.format("%o", 10)) 

   print()
   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0720.lua
