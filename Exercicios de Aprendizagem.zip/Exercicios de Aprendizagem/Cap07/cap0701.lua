-- inicio do programa cap0701.lua

   function pessoa(DADOS)
      print(DADOS.nome)
   end

   dofile("popula.lua")

   print()
   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0701.lua
