-- inicio do programa cap0716.lua

   REAL = 3.14159
   INTEIRO = math.floor(REAL)
   
   print("Valor real como inteiro ..: " .. INTEIRO)  
   print("Valor real como ..........: " .. REAL)  
   print("Valor inteiro como real ..: " .. INTEIRO + 0.0)  

   print()
   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0716.lua
