pessoa 
{
   nome = "Augusto",
   profissao = "Professor",
   idade = 45
}

pessoa 
{
   nome = "Antonio",
   profissao = "Medico",
   idade = 55
}

pessoa 
{
   nome = "Mariana",
   profissao = "Engenheiro",
   idade = 30
}

pessoa 
{
   nome = "Marcelo",
   profissao = "Medico",
   idade = 45
}
