-- inicio do programa cap0801.lua

   ARQTXT = io.open("arqtxt.tex","w")
   ARQTXT:close()

   print("Arquivo ARQTXT.TEX criado.")

   print()
   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0801.lua
