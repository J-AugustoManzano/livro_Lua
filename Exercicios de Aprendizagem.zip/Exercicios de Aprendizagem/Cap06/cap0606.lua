-- inicio programa cap0606.lua

   RAIZES = {
      math.sqrt(16),
      math.sqrt(25),
      math.sqrt(36),
      math.sqrt(49)
   }

   for I = 1, #RAIZES do
      print(RAIZES[I])
   end

   print()
   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim programa cap0606.lua
