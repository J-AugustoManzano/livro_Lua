-- inicio do programa cap0616.lua

   TABELA1 = {}
   TABELA2 = {}
   TABELA3 = {}

   TABELA1.a = 2
   TABELA1.b = 4
   TABELA1.c = 6

   TABELA2.a = 3
   TABELA2.b = 5
   TABELA2.c = 7

   TABELA3 = TABELA1 + TABELA2

   print(TABELA3.a)
   print(TABELA3.b)
   print(TABELA3.c)

   print()
   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0616.lua
