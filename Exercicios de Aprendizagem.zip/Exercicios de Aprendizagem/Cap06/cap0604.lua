-- inicio programa cap0604.lua

   DIA_SEMANA = {
      "domingo",
      "segunda-feira",
      "terca-feira",
      "quarta-feira",
      "quinta-feira",
      "sexta-feira",
      "sabado"
   }

   for I = 1, #DIA_SEMANA, 1 do 
      print(DIA_SEMANA[I])
   end

   print()
   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim programa cap0604.lua
