-- inicio do programa cap0303.lua

   io.write("Entre numero: ") N = tonumber(io.read())

   if (N >= 1) and (N <= 9) then
      print("Valor na faixa de 1 a 9")
   else
      print("Valor fora da faixa")
   end

   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0303.lua
