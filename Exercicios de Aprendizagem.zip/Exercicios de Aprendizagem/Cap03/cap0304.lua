-- inicio do programa cap0304.lua

   io.write("Entre seu sexo: ") S = io.read()

   if (S == "m") or (S == "f") then
      print("Sexo valido")
   else
      print("Sexo invalido")
   end

   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0304.lua
