-- inicio do programa cap0305.lua

   io.write("Entre um numero: ") N = tonumber(io.read())

   if not (N <= 3) then
      print(N)
   end

   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0305.lua
