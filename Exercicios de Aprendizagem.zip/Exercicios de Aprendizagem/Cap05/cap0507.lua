-- inicio do programa cap0507.lua

   print(string.char(65))    
   print(string.char(65, 66, 67))       

   print()
   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0507.lua
