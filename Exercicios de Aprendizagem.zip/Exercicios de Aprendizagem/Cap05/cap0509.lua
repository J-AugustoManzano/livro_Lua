-- inicio do programa cap0509.lua

   X = 33
   print(X)        -- mostra valor 33 
   if (X > 5) then
      local X = 5 
      print(X)     -- mostra valor  5 
   end
   print(X)        -- mostra valor 33

   print()
   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0509.lua
