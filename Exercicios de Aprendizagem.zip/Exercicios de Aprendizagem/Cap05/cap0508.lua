-- inicio do programa cap0507.lua

   print("Primeira mensagem")   
   os.execute("cls||clear") 
   print("Segunda mensagem")    

   print()
   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0507.lua
