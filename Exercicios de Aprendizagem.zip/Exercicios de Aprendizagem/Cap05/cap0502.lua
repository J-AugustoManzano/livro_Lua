-- inicio do programa cap0502.lua

   VALOR = 1.12

   print(math.cos(VALOR))
   print(math.sin(VALOR))
   print(math.tan(VALOR))
   print(math.sqrt(VALOR))
   print(math.floor(VALOR))

   print()
   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0502.lua
