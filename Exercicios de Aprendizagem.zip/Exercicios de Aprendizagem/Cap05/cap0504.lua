-- inicio do programa cap0504.lua

   X = "A BOLA AZUL APARECEU"

   print(string.gsub(X,"A","4"))
   print(string.gsub(X,"E","3",1))

   print()
   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0504.lua
