-- inicio do programa cap0501.lua

   FRASE = "Linguagem Lua"

   print(string.len(FRASE))
   print(#FRASE)
   print(string.lower(FRASE))
   print(string.upper(FRASE))
   print(string.reverse(FRASE))

   print()
   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0501.lua
