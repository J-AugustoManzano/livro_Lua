-- inicio do programa cap0505.lua

   X = "OBA "
   print(string.rep(X,2))

   print()
   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0505.lua
