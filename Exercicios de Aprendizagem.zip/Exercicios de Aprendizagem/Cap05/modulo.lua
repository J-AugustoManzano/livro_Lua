-- inicio do programa MODULO

   function saudacao(NOME)
      print("Ola, " .. NOME)
   end

   function raiz(BASE,INDICE)
      local X = BASE ^ (1 / INDICE)
      return X
   end

-- fim do programa MODULO
