-- inicio do programa cap0510.lua

   function quadrado()
      QUAD = VLR * VLR
      return QUAD
   end

   VLR = tonumber(io.read())
   print(quadrado())

   print()
   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0510.lua
