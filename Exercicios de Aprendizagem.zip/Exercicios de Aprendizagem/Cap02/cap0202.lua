-- inicio do programa cap0202.lua

   io.write("Entre o 1o. valor: ") A = io.read("*number")
   io.write("Entre o 2o. valor: ") B = io.read("*number")

   X1 = A + B
   X2 = A - B
   X3 = A * B
   X4 = A / B

   print("Adicao .........: " .. X1)
   print("Subtracao ......: " .. X2)
   print("Multiplicacao ..: " .. X3)
   print("Divisao ........: " .. X4)

-- fim do programa cap0202.lua
