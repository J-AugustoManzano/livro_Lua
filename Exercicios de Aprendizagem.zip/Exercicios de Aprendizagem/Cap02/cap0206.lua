-- inicio do programa cap0206.lua

   io.write("Entre um valor: ")
   N = tonumber(io.read())

   X = N ^ 2

   print(N .. " ^ 2 = " .. X)

-- fim do programa cap0206.lua
