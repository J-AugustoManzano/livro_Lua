-- inicio do programa cap0201.lua

   io.write("Entre o 1o. valor: ") A = io.read("*number")
   io.write("Entre o 2o. valor: ") B = io.read("*number")

   X1 = A + B
   X2 = A - B
   X3 = A * B
   X4 = A / B

   io.write("Adicao .........: ", X1, "\n")
   io.write("Subtracao ......: ", X2, "\n")
   io.write("Multiplicacao ..: ", X3, "\n")
   io.write("Divisao ........: ", X4, "\n")

-- fim do programa cap0201.lua
