-- inicio do programa cap0207.lua

   io.write("Entre o 1o. valor: ")
   A = tonumber(io.read())

   io.write("Entre o 2o. valor: ")
   B = tonumber(io.read())

   X = A + B

   io.write("Adicao = ", X, "\n\n")

   io.write("Tecla <Enter> para encerrar...")
   io.read('*l')

-- fim do programa cap0207.lua
