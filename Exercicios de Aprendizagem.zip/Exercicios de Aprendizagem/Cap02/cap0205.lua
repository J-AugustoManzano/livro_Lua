-- inicio programa cap0205.lua

   print("Linguagem " .. "Lua")
   print(1 .. 2)
   print("Lua " .. 2018)

-- fim programa cap0205.lua
