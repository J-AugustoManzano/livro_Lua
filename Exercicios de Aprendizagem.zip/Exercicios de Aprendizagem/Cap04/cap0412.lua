-- inicio do programa cap0412.lua

   I = 1
   while (I <= 10) do
      print(I)
      do
         break
      end
      I = I + 1
   end

   print()
   io.write("Tecle <Enter> para encerrar...")
   io.read '*l'

-- fim do programa cap0412.lua
